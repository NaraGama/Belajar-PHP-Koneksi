<!DOCTYPE html>
<html>
    <head>
        <title>Form Login</title>
    </head>
    <body>
        <div>
            <pre>
                <h3>Masukkan Data Anda Dibawah Ini  :</h3>
                <hr>
                <form method="post" action="proses_form.php">
                    Nama    : <input type="text" name="Name" size="20"><br>
                    Email   : <input type="text" name="email" size="20"><br>
                    Pesan   : <textarea name="message" rows="2" cols="50"></textarea><br>
                    <input type="submit" value="Kirim">     <input type="reset" value="Batal">
                </form>
            </pre>
        </div>
    </body>
</html>
